'use strict';

require('dotenv').config();
const express = require('express');
const mineflayer = require('mineflayer');

const app = express();
const PORT = numberEnv('PORT', 10000, 1);
const CONFIG = {
  host: process.env.MC_HOST || 'blastmc.mangoohost.live',
  port: numberEnv('MC_PORT', 20987, 1),
  // 'auto' lets Mineflayer detect the actual backend protocol.
  // This is useful behind ViaVersion / multi-version proxies.
  version: (process.env.MC_VERSION || 'auto').trim(),
  username: process.env.BOT_USERNAME || 'BlastMC_AFk',
  loginPassword: process.env.AUTHME_PASSWORD || '',
  registerPassword: process.env.AUTHME_REGISTER_PASSWORD || '',
  retryMs: numberEnv('RETRY_MS', 30000, 1000),
  maxRetryMs: 60000,
  moveEveryMs: numberEnv('MOVE_EVERY_MS', 3000, 1000),
  moveBurstMs: numberEnv('MOVE_BURST_MS', 700, 100),
  jumpEveryMs: numberEnv('JUMP_EVERY_MS', 6000, 1000),
  stableResetMs: numberEnv('STABLE_RESET_MS', 60000, 10000)
};

function numberEnv(name, fallback, min) {
  const value = Number(process.env[name] ?? fallback);
  return Number.isFinite(value) && value >= min ? value : fallback;
}

let bot = null;
let activeSession = null;
let connecting = false;
let online = false;
let stopping = false;
let reconnectTimer = null;
let reconnectAttempts = 0;
let lastError = null;
let nextSessionId = 0;

function log(message) {
  console.log(`[${new Date().toISOString()}] ${message}`);
}

function health() {
  return {
    status: online ? 'online' : 'offline',
    connecting,
    reconnectAttempts,
    host: CONFIG.host,
    port: CONFIG.port,
    version: CONFIG.version,
    botUsername: CONFIG.username,
    lastError,
    timestamp: new Date().toISOString()
  };
}

function isCurrent(session) {
  return activeSession === session && !session.closed && bot === session.bot;
}

function addTimeout(session, fn, ms) {
  const timer = setTimeout(() => {
    session.timeouts.delete(timer);
    if (isCurrent(session)) fn();
  }, ms);
  session.timeouts.add(timer);
  return timer;
}

function addInterval(session, fn, ms) {
  const timer = setInterval(() => {
    if (isCurrent(session)) fn();
  }, ms);
  session.intervals.add(timer);
  return timer;
}

function clearSession(session) {
  if (!session) return;
  session.closed = true;
  for (const timer of session.timeouts) clearTimeout(timer);
  for (const timer of session.intervals) clearInterval(timer);
  session.timeouts.clear();
  session.intervals.clear();
  try { session.bot.clearControlStates(); } catch (_) {}
}

function chat(session, message) {
  if (!isCurrent(session) || !online) return false;
  try {
    session.bot.chat(message);
    return true;
  } catch (error) {
    lastError = error.message || String(error);
    log(`Chat command error: ${lastError}`);
    return false;
  }
}

function sendAuth(session, mode) {
  if (!isCurrent(session) || session.authSent.has(mode)) return;
  const password = mode === 'register' ? CONFIG.registerPassword : CONFIG.loginPassword;
  if (!password) return;
  const command = mode === 'register'
    ? `/register ${password} ${password}`
    : `/login ${password}`;
  if (chat(session, command)) {
    session.authSent.add(mode);
    log(`AuthMe ${mode} command sent (password hidden).`);
  }
}

function inspectAuthMessage(session, text) {
  if (!isCurrent(session) || !text) return;
  const value = String(text).toLowerCase();
  const registerPrompt = /\/register|register|registr|create (an )?account|not registered|unregistered|please register/.test(value);
  const loginPrompt = /\/login|\blog ?in\b|authenticate|please log in|please login|please authenticate/.test(value);

  // Prefer the command specifically requested by the server's prompt.
  if (registerPrompt && CONFIG.registerPassword) sendAuth(session, 'register');
  else if (loginPrompt && CONFIG.loginPassword) sendAuth(session, 'login');
}

function startMovement(session) {
  const directions = ['forward', 'back', 'left', 'right'];
  addInterval(session, () => {
    try {
      session.bot.clearControlStates();
      const direction = directions[Math.floor(Math.random() * directions.length)];
      session.bot.setControlState(direction, true);
      addTimeout(session, () => {
        try { session.bot.clearControlStates(); } catch (_) {}
      }, CONFIG.moveBurstMs);
      log(`AFK movement: ${direction}`);
    } catch (error) {
      lastError = error.message || String(error);
      log(`Movement error: ${lastError}`);
    }
  }, CONFIG.moveEveryMs);

  addInterval(session, () => {
    try {
      session.bot.setControlState('jump', true);
      addTimeout(session, () => {
        try { session.bot.setControlState('jump', false); } catch (_) {}
      }, 250);
    } catch (error) {
      lastError = error.message || String(error);
      log(`Jump error: ${lastError}`);
    }
  }, CONFIG.jumpEveryMs);
}

function scheduleReconnect(reason) {
  if (stopping || reconnectTimer) return;
  lastError = reason || lastError || 'Connection ended';
  online = false;
  connecting = false;

  const oldSession = activeSession;
  const oldBot = bot;
  if (oldSession) clearSession(oldSession);
  activeSession = null;
  bot = null;

  reconnectAttempts += 1;
  const exponent = Math.min(reconnectAttempts - 1, 10);
  const delay = Math.min(CONFIG.retryMs * (2 ** exponent), CONFIG.maxRetryMs);
  log(`Disconnected. Retry ${reconnectAttempts} in ${Math.ceil(delay / 1000)}s. Reason: ${lastError}`);

  if (oldBot) {
    try { oldBot.quit('Reconnect scheduled'); } catch (_) {}
  }

  reconnectTimer = setTimeout(() => {
    reconnectTimer = null;
    connectBot();
  }, delay);
}

function connectBot() {
  if (stopping || connecting || bot || reconnectTimer) return;
  connecting = true;
  online = false;
  const id = ++nextSessionId;
  log(`Connecting to ${CONFIG.host}:${CONFIG.port}; requested version=${CONFIG.version}; username=${CONFIG.username}`);

  let newBot;
  try {
    const options = {
      host: CONFIG.host,
      port: CONFIG.port,
      username: CONFIG.username,
      auth: 'offline',
      hideErrors: false
    };
    if (CONFIG.version && CONFIG.version.toLowerCase() !== 'auto') {
      options.version = CONFIG.version;
    } else {
      options.version = false; // Mineflayer protocol autodetection
    }
    newBot = mineflayer.createBot(options);
  } catch (error) {
    connecting = false;
    lastError = error.message || String(error);
    log(`Bot creation failed: ${lastError}`);
    scheduleReconnect(lastError);
    return;
  }

  bot = newBot;
  const session = {
    id,
    bot: newBot,
    closed: false,
    authSent: new Set(),
    timeouts: new Set(),
    intervals: new Set()
  };
  activeSession = session;

  newBot.on('login', () => log('Minecraft login accepted; waiting for spawn.'));

  newBot.on('spawn', () => {
    if (!isCurrent(session)) return;
    connecting = false;
    online = true;
    lastError = null;
    log('Bot spawned successfully.');

    // Reset backoff only after the connection stays healthy for a while.
    addTimeout(session, () => {
      if (isCurrent(session) && online) {
        reconnectAttempts = 0;
        log('Stable connection; reconnect backoff reset.');
      }
    }, CONFIG.stableResetMs);

    // Required AuthMe check exactly 1.5 seconds after spawn.
    addTimeout(session, () => {
      if (CONFIG.loginPassword) sendAuth(session, 'login');
      else if (CONFIG.registerPassword) sendAuth(session, 'register');
    }, 1500);
    startMovement(session);
  });

  // Mineflayer parsed chat + string fallback.
  newBot.on('messagestr', message => inspectAuthMessage(session, message));
  newBot.on('message', message => {
    try { inspectAuthMessage(session, message.toString()); }
    catch (error) { log(`Chat fallback error: ${error.message}`); }
  });

  newBot.on('kicked', reason => {
    let detail;
    try { detail = typeof reason === 'string' ? reason : JSON.stringify(reason); }
    catch (_) { detail = String(reason); }
    lastError = `Kicked: ${detail}`;
    log(lastError);
  });

  newBot.on('error', error => {
    if (!isCurrent(session)) return;
    lastError = error.message || String(error);
    log(`Minecraft error: ${lastError}`);
    scheduleReconnect(lastError);
  });

  newBot.on('end', reason => {
    if (!isCurrent(session)) return;
    const detail = String(reason || 'Connection ended');
    log(`Minecraft connection ended: ${detail}`);
    scheduleReconnect(detail);
  });
}

app.get('/', (_req, res) => res.status(200).send('BlastMC AFK Bot service is running.'));
app.get('/health', (_req, res) => {
  const state = health();
  res.status(state.status === 'online' ? 200 : 503).json(state);
});

const server = app.listen(PORT, '0.0.0.0', () => {
  log(`HTTP server listening on 0.0.0.0:${PORT}`);
  connectBot();
});

process.on('unhandledRejection', reason => {
  lastError = reason instanceof Error ? reason.message : String(reason);
  log(`Unhandled rejection: ${lastError}`);
});

process.on('uncaughtException', error => {
  lastError = error.message || String(error);
  log(`Uncaught exception: ${error.stack || lastError}`);
  // Keep the HTTP endpoint available; log the issue for diagnosis.
});

function shutdown(signal) {
  if (stopping) return;
  stopping = true;
  online = false;
  connecting = false;
  log(`Received ${signal}; shutting down.`);
  if (reconnectTimer) clearTimeout(reconnectTimer);
  reconnectTimer = null;
  if (activeSession) clearSession(activeSession);
  const oldBot = bot;
  bot = null;
  activeSession = null;
  if (oldBot) {
    try { oldBot.quit('Service shutting down'); } catch (_) {}
  }
  server.close(() => process.exit(0));
  setTimeout(() => process.exit(0), 2000).unref();
}
process.on('SIGTERM', () => shutdown('SIGTERM'));
process.on('SIGINT', () => shutdown('SIGINT'));
