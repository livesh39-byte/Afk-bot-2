# BlastMC AFK Bot

Mineflayer AFK bot for `blastmc.mangoohost.live:20987`, with protocol auto-detection, AuthMe login/register support, controlled random movement, reconnect backoff, and an HTTP health endpoint.

## What's included

- `index.js` — bot, AuthMe prompt fallback, AFK movement, reconnect, health endpoints
- `package.json` — Node.js 20+ and dependencies
- `.env.example` — safe sample configuration
- `.gitignore` — ignores secrets, logs, and dependencies
- `render.yaml` — Render Blueprint configuration

## Minecraft 26.1 and multi-version servers

`MC_VERSION=auto` asks Mineflayer to detect the server protocol. The current upstream Mineflayer project lists support for Minecraft 26.1 and 1.21.11. A server/proxy that accepts multiple client versions does not mean every bot library version supports every protocol, so keep Mineflayer updated if the protocol changes. Auto-detection cannot bypass server-side access rules, whitelist requirements, AuthMe, or network restrictions.

## Render deploy

1. Put all project files, including `render.yaml`, in a GitHub repository.
2. In Render, create a new Blueprint and select that repository. Render reads `render.yaml` and proposes the service configuration.
3. Enter your real AuthMe password in the Render environment-variable prompt for the relevant key only. Use `AUTHME_PASSWORD` for an already-registered account, or `AUTHME_REGISTER_PASSWORD` for an account that needs registering. Leave the other one blank/unset. Never commit a real password.
4. Set `BOT_USERNAME` to a username available to the server, if the default is taken.
5. Deploy and inspect the logs.

Render will supply `PORT` automatically. The included health check uses `/`, which remains HTTP 200 while the Minecraft bot is offline/reconnecting. `/health` returns the bot's detailed state and returns HTTP 503 while the bot is offline.

## Commands / local run

Node.js 20 or newer is required.

```bash
npm install
cp .env.example .env
npm start
```

On Windows, copy `.env.example` to `.env` manually. Fill in the environment values before starting. Do not commit `.env`.

## Environment variables

| Variable | Default | Meaning |
|---|---|---|
| `MC_HOST` | `blastmc.mangoohost.live` | Server hostname |
| `MC_PORT` | `20987` | Server port |
| `MC_VERSION` | `auto` | Protocol auto-detection; can be set to a supported exact version |
| `BOT_USERNAME` | `BlastMC_AFk` | Bot's Minecraft username |
| `AUTHME_PASSWORD` | empty | Password for an already registered AuthMe account |
| `AUTHME_REGISTER_PASSWORD` | empty | Password used for first-time AuthMe registration |
| `RETRY_MS` | `30000` | Initial reconnect delay, capped at 60 seconds |
| `MOVE_EVERY_MS` | `3000` | Movement interval |
| `MOVE_BURST_MS` | `700` | Duration of each directional movement |
| `JUMP_EVERY_MS` | `6000` | Jump interval |
| `STABLE_RESET_MS` | `60000` | Healthy duration before retry backoff resets |
| `PORT` | `10000` locally | HTTP port; Render supplies this automatically |

## Health endpoints

- `GET /` — simple service status; HTTP 200 while the web service is running.
- `GET /health` — JSON with `status`, `connecting`, `reconnectAttempts`, `host`, `port`, `version`, `botUsername`, `lastError`, and `timestamp`.

## Troubleshooting

- **Version/protocol error:** check Render logs and update Mineflayer to a release supporting the server's actual protocol.
- **AuthMe fails:** ensure only the relevant password variable is set, credentials are correct, and the server permits the account to register/login.
- **Connection refused/timeout:** confirm the hostname/port and that the host allows external connections.
- **Whitelist or anti-bot block:** configure the server to allow this bot. The script cannot bypass access controls or anti-bot systems.
- **Render free plan:** free services may sleep and are not guaranteed to run continuously. An always-on plan is required for reliable 24/7 hosting.

## Security

Do not share your AuthMe password, put it in source code, or commit `.env`. Use Render's private environment variables.
